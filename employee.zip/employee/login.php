<?php

$adminarr = $pwarr = $error ="";
$pw="";
if(isset($_REQUEST['submit'])){

    if(empty($_POST['admin'] && $_POST['pw'])){
        $error = "required";
    }
    // elseif(!preg_match("/^[a-zA-Z-' ]*$/",$_POST['admin'])){
    //     $adminarr = "only character and letter ";    
    // }
    elseif($_POST['admin'] != "admin@gmail.com"){
        $adminarr = "not match";
    }
    elseif($_POST['pw'] != "admin123"){
        $pwarr = "wrong ";
    }
    else{
        header('location:display.php');
    }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <style>
        .container{
            margin-top: 30px;
            padding:40px;
            border:2px solid black;
        }
        h2{
            text-align: center;
        }
        .error{
            color:red;
        }
    </style>

</head>
<body>
    <div class="container">
        <form action="" method="POST">
            <span class="error">*<?php echo $error;?></span>
            <h2>ADMIN LOGIN</h2>
            <div class="form-group">
                <label for="">ADMIN NAME</label>
                <input type="text" class="form-control" name="admin"><span class="error">*<?php echo $adminarr;?>
            </div>
            <div class="form-group">
                <label for="">PASSWORD</label>
                <input type="text" class="form-control" name="pw"><span class="error">*<?php echo $pwarr;?>
            </div>
            
            <div class="form-group">
                <input type="submit" name="submit" class="btn btn-info">
                <input type="reset"  name="reset" class="btn btn-danger">
            </div>
        </form>
    </div>

</body>
</html>