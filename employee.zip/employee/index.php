<?php

if(isset($_REQUEST['submit'])){
    header('location:ragister.php');
}
if(isset($_REQUEST['login'])){
    header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <style>
        .container{
            border:2px solid black;
            margin-top:30px;
            padding:40px;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- <a href="ragister.php" class="btn btn-success">RAGISTER</a>
    <a href="login.php" class="btn btn-success">LOGIN</a> -->
    <div class="container">
        <form action="" method="POST">
        <h2>USER RAGISTRATION</h2><br>
        <button value="submit" class="btn btn-success" name="submit">RAGISTER</button>
        </form>
    </div>
    <div class="container">
        <form action="" method="POST">
        <h2>ADMIN LOGIN </h2><br>
        <button value="submit" class="btn btn-success" name="login">LOGIN</button>
        </form>
    </div>
    

</body>
</html>