<?php

session_start();

setcookie('email', $_SESSION['email'], time() - 60 * 60 * 24 * 10, "/");
// setcookie('password', $_SESSION['password'], time() - 60 * 60 * 24 * 10, "/");
session_unset();
session_destroy();
 
header('location:userlogin.php');
