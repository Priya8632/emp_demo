<?php
session_start();
include 'conn.php';

$emailarr = $pwarr ="";

if(isset($_SESSION['email']) || isset($_COOKIE['email'])){
    header('locatiopn : dashboard.php');
}

if(isset($_POST['submit'])){

    $email = $_POST['email'];
    $password = $_POST['password'];
    $remember = $_POST['remember'];
    
    $sql = "SELECT * FROM employee WHERE email='$email'";
    $query = mysqli_query($conn,$sql);
    $arr = mysqli_fetch_assoc($query); 
    $row = mysqli_num_rows($query);
    setcookie('email',$email,time()+60*60*24*10,"/" );
      if ($row > 0 ) {
        if($arr['p_word'] == $password){

        $_SESSION['email'] = $arr['email'];
            header('location:dashboard.php'); 
        } else{
            echo "invalid email password";
        }
      }      
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <style>
        .container{
            margin-top: 30px;
            padding:40px;
            border:2px solid black;
        }
        h2{
            text-align: center;
        }
        .error{
            color:red;
        }
    </style>

</head>
<body>
    <div class="container">
        <form action="" method="POST">
            
            <h2>USER LOGIN</h2>
            <div class="form-group">
                <label for="">USER NAME</label>
                <input type="email" class="form-control" name="email"><span class="error">*<?php echo $emailarr;?>
            </div>
            <div class="form-group">
                <label for="">PASSWORD</label>
                <input type="text" class="form-control" name="password"><span class="error">*<?php echo $pwarr;?>
            </div>
            <input type="checkbox" name="remember" value="1">keep me sign in<br>
            
            
            
            <div class="form-group">
                <input type="submit" name="submit" class="btn btn-info">
                <input type="reset"  name="reset" class="btn btn-danger">
            </div>
        </form>
    </div>

</body>
</html>