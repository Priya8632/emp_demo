<?php

include 'conn.php';
session_start();

if(!isset($_SESSION['email'])){
    $_SESSION['email'] = $_COOKIE['email'];
}

$email = $_SESSION['email'];
$sql =  "SELECT * FROM employee WHERE email='$email'";
$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result) > 0){
    while($rows = mysqli_fetch_assoc($result)){
        $id = $rows['id'];
        $fname = $rows['fname'];
        $lname= $rows['lname'];
        $email= $rows['email'];
        $pw= $rows['p_word'];
        $cw= $rows['c_word'];
        $gender= $rows['gender'];
        $age= $rows['age'];
        $dept= $rows['dept'];
        $doj= $rows['doj'];
        $sal= $rows['sal'];
        $chkbox= $rows['hobby'];
        $img = $rows['img'];
              
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <style>
        table{
            margin-top:50px;
        }
        h2{
            color:blue;
            float:right;
        }
        body{
            margin:10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
    <h2>Welcome to: <?php echo $_SESSION['email']; ?></h2> 
    <a href="userlogout.php" class="btn btn-danger">log out</a>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>FNAME</th>
                    <th>LNAME</th>
                    <th>EMAIL</th>
                    <th>PASSWORD</th>
                    <th>CONFIRM PASSWORD</th>
                    <th>GENDER</th>
                    <th>AGE</th>
                    <th>DAPARTMENT</th>
                    <th>DATE OF JOIN</th>
                    <th>SALARY</th>
                    <th>HOBBIES</th>
                    <th>IMAGE</th>
                    <th>EDIT</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo $id; ?></td>
                    <td><?php echo $fname; ?></td>
                    <td><?php echo $lname; ?></td>
                    <td><?php echo $email;?></td>
                    <td><?php echo base64_decode($pw); ?></td>
                    <td><?php echo base64_decode($cw); ?></td>
                    <td><?php echo $gender; ?></td>
                    <td><?php echo $age; ?></td>
                    <td><?php echo $dept; ?></td>
                    <td><?php echo $doj; ?></td>
                    <td><?php echo $sal; ?></td>
                    <td><?php echo $chkbox;?></td>
                    <td><img src="<?php echo $img;?>" width="60px"></td>
                    <td><a href="user_update.php?user_update=<?php echo $id; ?>" class="btn btn-primary">UPDATE</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>